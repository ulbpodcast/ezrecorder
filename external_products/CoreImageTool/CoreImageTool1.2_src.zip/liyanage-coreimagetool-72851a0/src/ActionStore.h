//
//  ActionStore.h
//  CoreImageTool
//
//  Created by Marc Liyanage on 03.08.07.
//  Copyright 2007-2009 Marc Liyanage <http://www.entropy.ch>. All rights reserved.
//

#import "Action.h"

@interface ActionStore : Action {

}

@end
