//
//  ValueClassConverterNSAffineTransform.h
//  CoreImageTool
//
//  Created by Marc Liyanage on 05.08.07.
//  Copyright 2007-2009 Marc Liyanage <http://www.entropy.ch>. All rights reserved.
//

#import "ValueClassConverter.h"

@interface ValueClassConverterNSAffineTransform : ValueClassConverter {

}

@end
