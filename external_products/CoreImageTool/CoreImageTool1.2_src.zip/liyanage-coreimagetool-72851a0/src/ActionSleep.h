//
//  ActionSleep.h
//  CoreImageTool
//
//  Created by Marc Liyanage on 23.08.07.
//  Copyright 2007-2009 Marc Liyanage <http://www.entropy.ch>. All rights reserved.
//

#import "Action.h"

@interface ActionSleep : Action {

}

@end
